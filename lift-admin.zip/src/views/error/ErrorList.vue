<template>
  <div>
    <h1>错误列表页</h1>

  </div>
</template>

<script>
export default {
  data() {
    return {

    }
  },
  mounted() {

  },
  methods: {

  },
  components: {

  }
}
</script>

<style scoped>

</style>
