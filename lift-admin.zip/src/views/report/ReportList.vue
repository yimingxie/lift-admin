<template>
  <div>
    <h1>经营报表</h1>

  </div>
</template>

<script>
export default {
  data() {
    return {

    }
  },
  mounted() {

  },
  methods: {

  },
  components: {

  }
}
</script>

<style scoped>

</style>
