<template>
  <div id="staffDetails">
    <div class="bread-nav">
      <router-link to="/staff">
        <span>员工管理</span>
      </router-link>
      <em>/</em>
      <span class="on">彭于晏-员工详情</span>
    </div>
    <div class="main-wrap" >
      <div class="row" >
        <div class="panel" style="padding:0">
          <el-avatar shape="square" :size="210" :fit="fits" :src="url" class="s_pic" style=""></el-avatar>
          <div class="s_contain">
            <span class="s_de_edit"></span>

            <p class="s_de_name">彭于晏
              <img src="../../assets/images/hs/male.png"  alt="female" />
            </p>
            <p class="s_de_department">例行维保项目组</p>
            <div class="s_de_details">
              <ul>
                <li><span class="tie">手机号码：</span><span >13456789985</span></li>
                <li><span class="tie">出生日期：</span><span>1902-12-04  27岁</span></li>
                <li><span class="tie">从业资格证：</span><span>从业资格证.jpg</span></li>
                <li><span class="tie">从业日期：</span><span>2016-12-04  3年</span></li>
                <li><span class="tie">入职日期：</span><span>2016-12-04  2年</span></li>
                <li><span class="tie">管辖电梯数：</span><span>38部</span></li>
                <li><span class="tie">管辖区域：</span><span>深圳市南山区-蛇口，前海  福田-市中心</span></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      
      <div class="row" >
          
        <div class="panel" :class="open ? '':'closePanel'">
          <div class="title" style="border-bottom:none">
            <div class="label1">管辖电梯<span class="open"  @click="open = !open" v-text="open ? '收起' : '展开'"></span></div>
          </div>
        
          <!-- 表格 Start -->
          <div style="position:relative;display:flex;">
            &nbsp;
            <el-table :data="getAllAccountJson">
              <el-table-column prop="account" label="电梯编号">
              </el-table-column>
          
              <el-table-column prop="name" label="区域-片区">
              </el-table-column>
              
              <el-table-column  label="使用地点">
                <template slot-scope="scope">
                  <span v-html="scope.row.roleName"></span>
                </template>
              </el-table-column>
             
             
              <el-table-column label="操作" width="75">
                <template slot-scope="scope">
                  <!-- 1.在封装好的组件上使用，所以要加上.native才能click
                  2.prevent就相当于..event.preventDefault() -->
                  <el-button @click.native.prevent="editAccount(scope.$index, scope.row)" type="text">查看详情
                  </el-button>
                 
                </template>
              </el-table-column>
            </el-table>
            &nbsp;
          </div>
          <!-- 表格 End -->
          
          <!-- 分页 Start -->
          <div class="pagination_block">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page.sync="queryParam.offset"
              :page-sizes="[10, 20, 30]"
              :page-size="queryParam.limit"
              layout="prev, pager, next, sizes, jumper"
              :total="totalPageSize">
            </el-pagination>
          </div>
          <!-- 分页 End -->

        </div>
        
      </div>

      <div class="row" >
          
        <div class="panel">
          <div class="title" style="border-bottom:none"><div class="label1">作业记录</div></div>
          
        
          <!-- 表格 Start -->
          <div style="position:relative;;display:flex;">
            &nbsp;
            <el-table :data="getAllAccountJson">
              <el-table-column prop="account" label="工单编号">
              </el-table-column>
          
              <el-table-column prop="name" label="作业类型">
              </el-table-column>
              
              <el-table-column prop="roleName" label="作业电梯">
              </el-table-column>
          
              <el-table-column prop="name" label="处理进度">
              </el-table-column>
              
              <el-table-column prop="account" label="完成时间">
              </el-table-column>
            
              <el-table-column label="操作" width="75">
                <template slot-scope="scope">
                  <!-- 1.在封装好的组件上使用，所以要加上.native才能click
                  2.prevent就相当于..event.preventDefault() -->
                  <el-button @click.native.prevent="editAccount(scope.$index, scope.row)" type="text">查看详情
                  </el-button>
                 
                </template>
              </el-table-column>
            </el-table>
            &nbsp;
          </div>
          <!-- 表格 End -->
          
          <!-- 分页 Start -->
          <div class="pagination_block">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page.sync="queryParam.offset"
              :page-sizes="[10, 20, 30]"
              :page-size="queryParam.limit"
              layout="prev, pager, next, sizes, jumper"
              :total="totalPageSize">
            </el-pagination>
          </div>
          <!-- 分页 End -->

        </div>
        
      </div>

     
   
      <fotter></fotter>
    </div>
  </div>
</template>

<script>
import Vue from 'vue'
import api from 'api'
import RadioGroup from "../../components/RadioGroup";
import SearchInput from "../../components/SearchInput";
// import SearchBox from '../../components/SearchBox'
import fotter from "../../views/common/fotter";

export default {
  data() {
    return {
      getAllAccountJson:[],
      totalPageSize:0,
      queryParam:{
        offset:1,
        limit:10,
        column: "create_time",
        order: false,
        queryStr: "",
        corpId:window.localStorage.getItem('corpId')
      },
      fits:'cover',
      url: 'https://fuss10.elemecdn.com/e/5d/4a731a90594a4af544c0c25941171jpeg.jpeg',
      open: false
    }
  },
  components: {
    'fotter': fotter,
  },
  mounted() {
    this.getAllAccountData()
    console.log("params==" + this.$route.params.staffId)
  },
  methods: {
    // 查询所有账户
    getAllAccountData(){
      api.accountApi.getAccounts(this.queryParam).then((res) => {
        if(res.data.code === 200 && res.data.message === 'success'){
          this.getAllAccountJson = res.data.data.records
          this.totalPageSize = res.data.data.total

        } else {
          this.getAllAccountJson = []
        }
        
        // console.log("res.data.code" + res.data.data.records[0])s
      }).catch((res) => {
        
      })
     
    },
    // 展开
    open(){

    },
    // 每页条数变化
    handleSizeChange(val) {
      this.queryParam.limit = val
      // console.log(`每页 ${val} 条`);
      this.getAllAccountData()
    },

    // 当前页变化
    handleCurrentChange(val) {
      this.queryParam.offset = val
      // console.log(`当前页: ${val}`);
      this.getAllAccountData()
    },
    
    

  },
}
</script>

<style lang="stylus">
#staffDetails
  .bread-nav
    padding: 0 20px;
    height: 52px;
    line-height: 52px;
    background: #fff;
    border-bottom: 1px solid #e9e9e9;
    span 
      display: inline-block;
      font-size: 16px;
      color: #7e8a95;
      &.on
        color: #34414C;
    em
      display: inline-block;
      font-size: 16px;
      color: #7e8a95;
      margin: 0 10px;

  
  .s_contain
    height 210px
    padding: 33px 0
    margin-left:220px
  .s_pic
    position:absolute;
    box-shadow: 0 8px 20px -12px rgba(66,114,255,0.30);
    border-radius: 8px 0 0 8px;
  .s_de_edit
    background url('../../assets/images/hs/edit.png') no-repeat center;
    width 14px
    height 14px
    display: inline-block
    position absolute 
    top 35px 
    right 26px
    cursor pointer
  .s_de_name
    font-size: 24px;
    color: #34414C;
    margin-left: 36px
  .s_de_department
    font-size: 14px;
    color: #7E8A95;
    margin 10px 0 20px 36px
  .s_de_details 
    li
      float left
      font-size: 14px;
      color: #34414C;
      padding: 5px 12px 5px 39px;
      min-width: 201px;
    .tie
      font-size: 12px;
      color: #7E8A95;
  .open
    color: #4272FF;
    float: right;
    font-size: 14px;
    margin-right: 28px
    cursor pointer
  .closePanel
    height: 303px;
    overflow: hidden;

</style>
