<template>
<div id="department">
  <div class="bread-nav">
    <router-link to="/staff">
      <span>员工管理</span>
    </router-link>
    <em>/</em>
    <span class="on">部门管理</span>
  </div>
  <div class="main-wrap">
    <div class="row" >

      <div class="panel">
        <div class="title"><div class="label1">部门管理</div></div>
   
        <div class="subSelect">
    
          <!-- <el-cascader 
            filterable 
            class="regionPicker" 
            :options="regionOptions" 
            v-model="form.selectedOptions" 
            @change="handleChange" 
            :show-all-levels="false">
          </el-cascader> -->
          <div class="llct-area">
            <city-choose @childVal="selectCity"></city-choose>
          </div>
        </div>
        <div class="subBtns">
          <button class="btn blueBtn" @click="add_dialogFormVisible = true">添加部门</button>
          <search-input v-model.trim="searchKey" placeholderValue="搜索部门名称">
            <span slot="btn" class="search_btn" @click="searchAccount()" @keyup.enter.native="searchAccount()"></span>
          </search-input>
        </div>
        <div class="splitBar"></div>

        <!-- 表格 Start -->
        <div style="position:relative;;display:flex;">
          &nbsp;
          <el-table :data="getAllAccountJson" style="margin-top:30px">
            <el-table-column prop="account" label="部门">
            </el-table-column>
        
            <el-table-column prop="name" label="区域-片区">
            </el-table-column>
            <el-table-column prop="account" label="员工数量">
            </el-table-column>
            <el-table-column prop="account" label="部门负责人">
            </el-table-column>
            <el-table-column  label="创建时间">
              <template slot-scope="scope">
                <span v-html="scope.row.roleName"></span>
              </template>
            </el-table-column>
            
          
            <el-table-column label="操作" width="200">
              <template slot-scope="scope">
                <!-- 1.在封装好的组件上使用，所以要加上.native才能click
                2.prevent就相当于..event.preventDefault() -->
                <el-button @click.native.prevent="editAccount(scope.$index, scope.row)" type="text">编辑
                </el-button>
                <el-button  style="color: #E9645D;" @click.native.prevent="deleteAccount(scope.$index, scope.row)" type="text">删除
                </el-button>
              </template>
            </el-table-column>
          </el-table>
          &nbsp;
        </div>
        <!-- 表格 End -->
        
        <!-- 分页 Start -->
        <div class="pagination_block">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page.sync="queryParam.offset"
            :page-sizes="[10, 20, 30]"
            :page-size="queryParam.limit"
            layout="prev, pager, next, sizes, jumper"
            :total="totalPageSize">
          </el-pagination>
        </div>
        <!-- 分页 End -->

      </div>
      
    </div>
    <!-- 添加账号  弹窗  Start -->
    <el-dialog width="662px" title="创建部门" :visible.sync="add_dialogFormVisible">
      <el-form :model="addAccountForm" :label-width="formLabelWidth">
        <el-form-item label="部门名称:" prop="account">
          <el-input v-model="addAccountForm.account" auto-complete="off" clearable></el-input>
        </el-form-item>
        <!-- <el-form-item label="真实姓名：" prop="name">
          <el-input v-model="addAccountForm.name" auto-complete="off" clearable></el-input>
        </el-form-item>
        -->
      
        <el-form-item label="部门负责人：" prop="roleName" >
          <el-select v-model="addAccountForm.roleId" placeholder="请选择角色">
            <el-option
              v-for="item in rolesJson"
              :key="item.id"
              :label="item.name"
              :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="管辖区域：" prop="roleName" >
          <el-select v-model="addAccountForm.roleId" placeholder="请选择角色">
            <el-option
              v-for="item in rolesJson"
              :key="item.id"
              :label="item.name"
              :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer"  class="dialog-footer tac">
        <el-button @click="add_dialogFormVisible = false" class="dialogCancel">取 消</el-button>
        <el-button type="primary" @click="confirmAddAccount()" class="dialogSure">确 认</el-button>
      </div>
    </el-dialog>
    <!--添加账号  弹窗 End -->
    <fotter></fotter>
  </div>
</div>
</template>

<script>
import Vue from 'vue'
import api from 'api'
import RadioGroup from "../../components/RadioGroup";
import SearchInput from "../../components/SearchInput";
import fotter from "../../views/common/fotter";
import CityChoose from '../../components/CityChoose'

export default {
  data() {
    return {
      totalPageSize:0, // 总页数
      queryParam:{
        // pageNo: 1,
        // pageSize: 100,
        offset:1,
        limit:10,
        column: "create_time",
        order: false,
        queryStr: "",
        corpId:window.localStorage.getItem('corpId')
      },
      getAllAccountJson: [],
      formLabelWidth: '106px',
      add_dialogFormVisible:false,
      addAccountForm: {
        account: '',
        password: '111',
        corpId: window.localStorage.getItem('corpId'),
        accountType: "1",
        userType: "staff",
        roleId:''
      },
      searchKey:'',
      selectedDpt:'',
      departments:[{
          value: '选项1',
          label: '黄金糕'
        }, {
          value: '选项2',
          label: '双皮奶'
        }, {
          value: '选项3',
          label: '蚵仔煎'
      }],
    }
  },
  components: {
    'search-input': SearchInput,
    'fotter': fotter,
    'city-choose': CityChoose,
  },
  mounted() {
    this.getAllDepartmentData()
  },
  methods: {
    // 区域筛选
    selectCity(cityArr, cnName) {
      // this.liftListParams.areaCode = cityArr[cityArr.length-1]
      // console.log(cnName)
      // this.getLiftList()
    },
    // 查询所有账户
    getAllDepartmentData(){
      api.accountApi.getAccounts(this.queryParam).then((res) => {
        if(res.data.code === 200 && res.data.message === 'success'){
          this.getAllAccountJson = res.data.data.records
          this.totalPageSize = res.data.data.total

        } else {
          this.getAllAccountJson = []
        }
        
        // console.log("res.data.code" + res.data.data.records[0])s
      }).catch((res) => {
        
      })
      
    },
  

    // 每页条数变化
    handleSizeChange(val) {
      this.queryParam.limit = val
      // console.log(`每页 ${val} 条`);
      this.getAllDepartmentData()
    },

    // 当前页变化
    handleCurrentChange(val) {
      this.queryParam.offset = val
      // console.log(`当前页: ${val}`);
      this.getAllDepartmentData()
    },
    

    // 确认添加账号
    confirmAddAccount() {
      console.log('submit!');
      api.accountApi.createAccount(this.addAccountForm).then((res) => {
        this.adding = false
        
        if (res.data.code === 200) {
          // 修改角色
          // this.bindRoleForm.userId = 
          // api.accountApi.accountBindRole(this.bindRoleForm).then((res) => {
          //   if (res.data.code === 200) {
          this.$message.success('创建成功！');
          this.getAllDepartmentData()
          this.add_dialogFormVisible = false
             
          //   }
          // }).catch((res) => {
          //   this.$message.error(res.data.message);
          // })
          
        } else {
          this.$message.error(res.data.message);
          
        }
        // this.resetAdd()
      }).catch((res) => {
        // this.handleError(res)
        // this.adding = false
      })
    },

    // 搜索真实姓名/手机号
    searchAccount(){
      this.queryParam.queryStr = this.searchKey
      this.getAllDepartmentData()
    }

  },
}
</script>

<style lang="stylus">
#department
  .bread-nav
    padding: 0 20px;
    height: 52px;
    line-height: 52px;
    background: #fff;
    border-bottom: 1px solid #e9e9e9;
    span 
      display: inline-block;
      font-size: 16px;
      color: #7e8a95;
      &.on
        color: #34414C;
    em
      display: inline-block;
      font-size: 16px;
      color: #7e8a95;
      margin: 0 10px;
  
  .llct-area
    float left;
    width 120px;
    height 30px;
    .el-cascader__label, .el-input__inner
      padding-left:0!important
      border: none!important;
</style>
