<template>
<div class="main-wrap" id="AddStaff">
  <div class="row" >

    <div class="panel" >
      <div class="title"><div class="label1">添加员工</div></div>
      <div class="content">
        <!-- http-request：覆盖默认的上传行为，可以自定义上传的实现
        show-file-list：是否显示已上传文件列表，默认是true
        multiple：是否支持多选文件
        action：必选参数，上传的地址
        （如果不自定义上传行为，可以直接在action配置地址就行，没有地址可以为空，但是不能不写action） -->

        <el-upload 
          class="avatar-uploader"
          :http-request="Upload" 
          :multiple="true" 
          :show-file-list="false" 
          :on-success="handleAvatarSuccess"
          action="">
          <img v-if="imageUrl" :src="imageUrl" class="avatar">
          <i v-else class="uploader-icon"></i>
          <div class="uploadBtn">点击上传员工照片</div>
          <div class="uploadTip">图片格式为.jpg/.png；建议图片尺寸为300像素*300像素，图片大小不可超过2M</div>
        </el-upload>

        <el-form ref="form" :model="form" label-width="105px">
          <el-row>
            <el-col :span="12">
              <el-form-item label="姓名：">
                <el-input v-model="form.name"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="11" :offset="1">
              <el-form-item label="性别：">
                <div class="chooseSex">
                  <label class="btn male" :class="form.sex === 0 ? 'active': ''">
                    <input type="radio" autocomplete="off" @click="onSelectSex(0)"/>
                  </label>
                  <label class="btn female" :class="form.sex === 1 ? 'active': ''">
                    <input type="radio" autocomplete="off" @click="onSelectSex(1)"/>
                  </label>
                </div>
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item label="手机号：">
            <el-input v-model="form.name"></el-input>
          </el-form-item>
          <el-form-item label="出生日期：">
            <a-date-picker @change="aChangePickDate" format="YYYY-MM-DD" :showToday="false" placeholder="请选择日期" style="width: 248px">
            </a-date-picker>
          </el-form-item>
          <el-form-item label="从业日期：">
            <a-date-picker @change="aChangePickDate" format="YYYY-MM-DD" :showToday="false" placeholder="请选择日期" style="width: 248px">
            </a-date-picker>
          </el-form-item>
          <el-form-item label="入职日期：">
            <a-date-picker @change="aChangePickDate" format="YYYY-MM-DD" :showToday="false" placeholder="(选填)请选择日期" style="width: 248px">
            </a-date-picker>
          </el-form-item>
          <el-form-item label="部门：">
            <!-- <el-select v-model="form.region" placeholder="请选择部门">
              <el-option label="区域一" value="shanghai"></el-option>
              <el-option label="区域二" value="beijing"></el-option>
            </el-select> -->
            <choiceindex clearable filterable @change="regionChange" :is-two-dimension-value="false" v-model="checkList" :data="regionOptions"></choiceindex>

          </el-form-item>
          <el-form-item label="管辖区域：">
            <!-- <el-cascader 
              filterable 
              :props="props" 
              :options="regionOptions" 
              v-model="areaForm.selectedOptions" 
              @change="handleChange" 
              :show-all-levels="false" clearable
               style="width: 100%"
              >
            </el-cascader> -->
            <choiceindex clearable filterable @change="regionChange2" :is-two-dimension-value="false" v-model="checkList2" :data="regionOptions2"></choiceindex>
            
          </el-form-item>
          <el-form-item >
            <span slot="label">管辖电梯：<div class="subTip" >（第一负责人）</div></span>
            <!-- <div v-for="">
               <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选</el-checkbox>
              <el-checkbox-group v-model="checkedLifts">
                <el-checkbox :label="account.account" :key="index" class="checkbox16">{{nonetext}}</el-checkbox>
              </el-checkbox-group>
            </div> -->
            <!-- <el-select
              style="width:100%;height:100%;"
              v-model="selectedLabels"
              multiple
              :popper-class="innerPopperClass"
              :filterable="filterable"
              :filter-method="innerFilterMethod"
              :reserve-keyword="reserveKeyword"
              @change="changeLabel"
            >
              <el-option>
                
              </el-option>
            </el-select> -->

            <el-row>
              <search-input v-model.trim="searchKey" placeholderValue="搜索电梯注册代码">
                <span slot="btn" class="search_btn" @click="searchAccount()" @keyup.enter.native="searchAccount()"></span>
              </search-input>
            </el-row>
            <el-row>
              <el-col :span="20">
                <div class="grid-content bg-purple">
                  {{liftList[0].address}}
                </div>
              </el-col>
              <el-col :span="4">
                <el-checkbox v-model="checkAll" @change="handleCheckAllChange"></el-checkbox>
              </el-col>
              <el-row class="grid-content bg-purple-light" v-for="lift in liftList[0].lifts " :key="lift.id">
                <el-col :span="7">
                  {{lift.order}}
                </el-col>
                <el-col :span="3">
                  {{lift.code}}
                </el-col>
                <el-col :span="10">
                  {{lift.address}}
                </el-col>
                <el-col :span="4">
                  <el-checkbox-group v-model="checkedStaffs" @change="handleCheckedLiftsChange">
                    <el-checkbox  :label="lift.id" :key="lift.id"></el-checkbox>
                  </el-checkbox-group>
                </el-col>
              </el-row>
            </el-row>
            
            <div style="margin: 15px 0;"></div>
            
            <!-- <el-select v-model="form.region" placeholder="请选择部门">
              <el-option label="区域一" value="shanghai"></el-option>
              <el-option label="区域二" value="beijing"></el-option>
            </el-select> -->
          </el-form-item>
          <el-form-item >
            <span slot="label">管辖电梯：<div class="subTip" >（第二负责人）</div></span>

            <!-- <el-select v-model="form.region" placeholder="请选择部门">
              <el-option label="区域一" value="shanghai"></el-option>
              <el-option label="区域二" value="beijing"></el-option>
            </el-select> -->
          </el-form-item>
          <el-form-item label="从业资格证：">
            <el-row >
              <el-col :span="5">
                <el-upload
                  class="avatar-uploader2"
                  action="https://jsonplaceholder.typicode.com/posts/"
                  :show-file-list="false"
                  :on-success="handleAvatarSuccess2"
                  :before-upload="beforeAvatarUpload2">
                  <img v-if="imageUrl2" :src="imageUrl2" class="avatar2">
                  <i v-else class="avatar-uploader-icon2"></i>
                </el-upload>
              </el-col>
              <el-col :span="18">
                <span class="uploadTip2">(选填)图片格式为.jpg/.png；
                  <br>建议图片尺寸为300像素*300像素，图片大小不可超过2M</span>
              </el-col>
            </el-row>
          </el-form-item>
        
          <div class="tac" style="margin-top:33px">
            <router-link to="/staff"><el-button class="dialogCancel">取 消</el-button></router-link>

            <el-button type="primary" @click="confirmAddAccount()" class="dialogSure">确 认</el-button>
          </div>
        </el-form>
      </div>
    </div>

  </div>

  <fotter></fotter>
</div>
</template>

<script>
import Vue from 'vue'
import api from 'api'
import RadioGroup from "../../components/RadioGroup";
import SearchInput from "../../components/SearchInput";
import fotter from "../../views/common/fotter";
import newArea from "../../utils/newArea";
import { client } from '@/utils/alioss'
import choiceindex from "../../components/multi-cascader/multi-cascader"; //级联选择多选 完成
let pcas = require("../../utils/citySelector/pcas-code.json")

export default {
  data() {
    return {
      form: {
        name: '',
        region: '',
        date1: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        desc: '',
        sex:0
      },
      props: { 
        multiple: true
      },
      regionOptions: [],
      areaForm: {
        city : '',
        area : '',
        minarea : '',
        selectedOptions: [],//地区筛选数组
      },
      imageUrl: '',
      imageUrl2:'',
      // data:[], // 与element级联选择器格式一致
      checkList: ["110102001"],
      checkList2: [],
      regionOptions2:[],
      liftList: [],

      checkAll: false,
      checkedStaffs: [],
      checkedAllStaff:[],
      nonetext:'',
      searchKey:''
    }
  },
  components: {
    'fotter': fotter,
    choiceindex, //级联
    'search-input': SearchInput,

  },
  mounted() {
    // for(var i= 0; i<2 ; i++){
      var mission = {
        address:'南山区-蛇口',
        lifts:[{
            id:'1',
            order:'2345…5555',
            code:'DT-1',
            address:'花园城数码大厦a座',
          },{
            id:'2',
            order:'2345…5555',
            code:'DT-1',
            address:'花园城数码大厦a座',
        }]
        
      }
    // }
    this.liftList.push(mission)
    // 重置多选
    this.checkedAllStaff = []
    this.checkedStaffs = []
    this.checkAll = false
    console.log("this.getAllAccountJson==" + JSON.stringify(this.getAllAccountJson))
    this.liftList[0].lifts.forEach(item => {
      this.checkedAllStaff.push(item.id)
    })

    // }
    this.regionOptions = newArea.newAreaOption()
  },
  methods: {
    // 搜索真实姓名/手机号
    searchAccount(){
      // this.queryParam.queryStr = this.searchKey
      // this.getAllAccountData()
    },
     // 全选，非全选
    handleCheckAllChange(val) {
      this.checkedStaffs = val ? this.checkedAllStaff : [];
      // this.isIndeterminate = false;
      console.log("check:" + this.checkedStaffs)
    },
    // 点击多选框
    handleCheckedLiftsChange(value) {
      console.log("check:" + value)
      console.log("Allcheckop:==" + this.checkedAllStaff)
      let checkedCount = value.length;
      this.checkAll = checkedCount === this.liftList[0].lifts.length;
      // this.isIndeterminate = checkedCount > 0 && checkedCount < this.getAllAccountJson.length;
    },
    // 上传
    Upload(file) {
      console.log("file;;" + file.file.uid )
      const suffix = file.file.name.substr(file.file.name.indexOf("."));
      var fileName = 'hs/' + 'banner' + file.file.uid +suffix //  路径+时间戳+后缀名
      
      //定义唯一的文件名，打印出来的uid其实就是时间戳
        client().put(fileName, file.file).then(
          result => {
            // this.imageUrl = URL.createObjectURL(file.raw);
            // 大功搞成  
            //下面是如果对返回结果再进行处理，根据项目需要，下面是我们自己项目所用的，仅供参考
            // this.fileList[0] =
            // {
            //   'name': result.name, 
            //   'url': result.url 
            // }
          // uploadBannerPic(this.fileList).then(res => {
          //   //根据需要可能项目还需对自己的数据库进行保存
          // })
        })
    },
    // 上传文件之前的钩子
    beforeAvatarUpload2(file){},
    // 上传成功
    handleAvatarSuccess2(res, file) {
      // console.log("Successfile==" + JSON.stringify(file))
      // this.imageUrl = URL.createObjectURL(file.raw);
    },
    // 上传成功
    handleAvatarSuccess(res, file) {
      // console.log("Successfile==" + JSON.stringify(file))
      // this.imageUrl = URL.createObjectURL(file.raw);
    },
    // 切换地区选择器
    handleChange(value){
      console.log("11111:::"+ value)
      // this.form.city = this.myAddressCity(this.form.selectedOptions[0])
      // this.form.city = this.form.selectedOptions[0];
      // this.form.area = this.myAddressarea(this.form.selectedOptions[1])
      // this.form.minarea = this.myAddressMinarea(this.form.selectedOptions[2])
      // console.log('ddddd=====' + JSON.stringify(this.form))
      
      // this.liftListParams.areaCode = value[1]
      // this.map.setCity(this.form.area.trim());
      // this.getAllLiftPoint()

    },
    onSubmit() {
      console.log('submit!');
    },
    // 切换性别
    onSelectSex (value) {
      // this.value = value
      this.form.sex = value
    },
    // A日历选择框改变时触发
    aChangePickDate(date, dateString){
      console.log(date, dateString);
    },
    // 去重
    uniq(array){
      var temp = []; //一个新的临时数组
      for(var i = 0; i < array.length; i++){
          if(temp.indexOf(array[i]) == -1){
              temp.push(array[i]);
          }
      }
      return temp;
    },
    
    regionChange(val){
      var util = require("util")
      console.log("所选区域码:" + JSON.stringify(val))
      // 重置联动数据 
      this.regionOptions2 = []
      console.log("checkList1=" + this.checkList)
      this.checkList2 = this.checkList

      // alert(this.checkList.length)
      // var checkArr = this.checkList.split(",")
      if(this.checkList.length > 0){
        var sheng = this.checkList[0].substring(0,2)
        var shi = this.checkList[0].substring(0,4)
        var qu = []
        for(var i = 0 ; i< this.checkList.length; i++){
          // 去重
          
          // qu.forEach(item =>{
          //   if(item !== this.checkList[i].substring(0,6)){
            qu.push(this.checkList[i].substring(0,6))
            // 去重
            qu = this.uniq(qu)
          //   }
          // })
          console.log("所选区：" + qu)
        }
        // var aaa = this.regionOptions.filter(item => item.code === '11')

        // 构建员工管辖区域数据
        this.regionOptions.forEach((item, i) => {
          // 第一级
          let obj1 = {
            value: '',
            label: '',
            children: []
          }
          // 查找对应的省
          if(item.value === sheng){
            obj1.value = sheng
            obj1.label = item.label

            // 第二级
            let obj2 = {
              value: '',
              label: '',
              children: []
            }
            if (item.children) { // 二级循环
              
              item.children.forEach((secondItem, secondI) => {
                // 查找对应的市
                if(secondItem.value === shi){
                  obj2.value = shi
                  obj2.label = secondItem.label
                  obj1.children.push(obj2)

                  
                  if (secondItem.children) { // 三级循环
                    secondItem.children.forEach((thirdItem, thirdI) => {
                      // 查找对应的区，区有多个
                      for(var j = 0;j < qu.length; j++){
                        // 第三级
                        let obj3 = {
                          value: '',
                          label: '',
                          children: []
                        }
                        if(thirdItem.value === qu[j]){
                          obj3.value = qu[j]
                          obj3.label = thirdItem.label
                          obj2.children.push(obj3)
                          
                         
                        
                          if (thirdItem.children) { // 四级循环
                            thirdItem.children.forEach((forthItem, forthI) => {
                              // 查找对应的片区， 片区有多个
                              for(var i = 0;i < val.length; i++){
                                // 第四级
                                let obj4 = {
                                  value: '',
                                  label: '',
                                }
                                if(forthItem.value === val[i]){
                                  console.log("所选区-" + val[i])
                                  obj4.value = val[i]
                                  obj4.label = forthItem.label
                                  obj3.children.push(obj4)
                                }
                              }
                              
                            })
                          }
                        }
                      }
                    })

                  }
                }
              })
            }
            console.log("obj---==" + JSON.stringify(obj1))
            
            this.regionOptions2.push(obj1)
            
          }
          
          // newFormat[item.code] = item.name

        })
        // 构建员工管辖区域数据 end


        // console.log("aaa---" + aaa)

        console.log("省：" + sheng)
        console.log("市：" + shi)
        console.log("区：" + qu)



      }
    },
    regionChange2(val){
      // console.log("区域码2:" + this.checkList2)
    }
  },
}
</script>

<style lang="stylus">
// 工具类
@import '../../assets/stylus/utilities'
#AddStaff
  .el-input__inner
    // height: 32px!important;
    line-height: 32px!important;
  .el-form-item__label
    line-height: 32px!important;
    color: #34414C;
  .el-input__icon
    line-height: 32px!important;
  .content
    width:580px
    margin 50px auto
  .chooseSex
    .btn
      position relative
      size 30px
      text-align: center;
      cursor pointer
      display: inline-block;
      transition: opacity  .3s;
      opacity 0.3
      // transform scale(1.2)
      &.active
        // background: #4272FF;
        opacity 1
    .male
      background url('../../assets/images/hs/male.png') no-repeat left center;
    .female
      background url('../../assets/images/hs/female.png') no-repeat left center;
    input[type="radio"]
      absolute left top
      appearance none
      opacity 0
  .subTip
    transform:scale(0.8);
    font-size: 10px;
    color: #7E8A95;
    text-align: right;
    line-height: 6px;
    white-space: nowrap;

  .avatar-uploader{
    border-color: #409EFF;
    text-align: center;
    margin-bottom: 40px;
  }
  .uploader-icon {
    border-radius: 50%;
    font-size: 28px;
    color: #8c939d;
    width: 96px;
    height: 96px;
    line-height: 96px;
    text-align: center;
    display inline-block
    background url('../../assets/images/hs/add2.png') no-repeat center #D8DDDF;

  }
  .avatar {
    width: 96px;
    height: 96px;
    display: block;
  }
  .uploadBtn
    color: #34414C;
    margin: 6px 0;
  .uploadTip
    font-size: 12px;
    color: #7E8A95;

  .avatar-uploader2 .el-upload {
    background: #FFFFFF;
    border: 1px solid #D8DDDF;
    border-radius: 4px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader2 .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon2 {
    font-size: 28px;
    color: #8c939d;
    size 90px 120px
    line-height: 120px;
    text-align: center;
    display inline-block
    background url('../../assets/images/hs/add2.png') no-repeat center;

  }
  .avatar2 {
    size 90px 120px
    display: block;
  }
  .uploadTip2
    font-size: 12px;
    color: #7E8A95;
    absolute bottom 3px;
    line-height: 21px;
    margin-left: 3px;
</style>
